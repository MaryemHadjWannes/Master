# Sidebar

Responsive sidebar sample, built using pure HTML/CSS/JavaScript.

![Screen](docs/Sidebar_1.png)
![Screen](docs/Sidebar_2.png)
